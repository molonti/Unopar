using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MusicalInstrumentStore2
{
    public partial class TypeEditor : Form
    {
        public TypeEditor()
        {
            InitializeComponent();
        }
    }
}