namespace MusicalInstrumentStore2
{
    partial class LojaMusical
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtItemNumero5 = new System.Windows.Forms.TextBox();
            this.txtSubTotal4 = new System.Windows.Forms.TextBox();
            this.txtQuantidade4 = new System.Windows.Forms.TextBox();
            this.txtPrecoUnitario4 = new System.Windows.Forms.TextBox();
            this.txtDescricao4 = new System.Windows.Forms.TextBox();
            this.txtItemNumero4 = new System.Windows.Forms.TextBox();
            this.txtSubTotal3 = new System.Windows.Forms.TextBox();
            this.txtQuantidade3 = new System.Windows.Forms.TextBox();
            this.txtPrecoUnitario3 = new System.Windows.Forms.TextBox();
            this.txtDescricao3 = new System.Windows.Forms.TextBox();
            this.txtItemNumero3 = new System.Windows.Forms.TextBox();
            this.txtSubTotal2 = new System.Windows.Forms.TextBox();
            this.txtQuantidade2 = new System.Windows.Forms.TextBox();
            this.txtPrecoUnitario2 = new System.Windows.Forms.TextBox();
            this.txtDescricao2 = new System.Windows.Forms.TextBox();
            this.txtItemNumero2 = new System.Windows.Forms.TextBox();
            this.colItemName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colItemNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colUnitPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnNovoPedidoCliente = new System.Windows.Forms.Button();
            this.btnNovoEstoqueItem = new System.Windows.Forms.Button();
            this.txtSubTotal1 = new System.Windows.Forms.TextBox();
            this.txtQuantidade1 = new System.Windows.Forms.TextBox();
            this.txtPrecoUnitario1 = new System.Windows.Forms.TextBox();
            this.txtDescricao1 = new System.Windows.Forms.TextBox();
            this.txtItemNumero1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtDescricao5 = new System.Windows.Forms.TextBox();
            this.btnRemove4 = new System.Windows.Forms.Button();
            this.btnRemove3 = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnRemove2 = new System.Windows.Forms.Button();
            this.btnAbrir = new System.Windows.Forms.Button();
            this.btnRemove6 = new System.Windows.Forms.Button();
            this.txtNumeroRecibo = new System.Windows.Forms.TextBox();
            this.btnRemove5 = new System.Windows.Forms.Button();
            this.btnRemove1 = new System.Windows.Forms.Button();
            this.pbxEstoqueItem = new System.Windows.Forms.PictureBox();
            this.cbxTipos = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cbxCategorias = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lvwEstoqueItems = new System.Windows.Forms.ListView();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTotalOrder = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.txtItemsTotal = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTotalPedido = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtValorImposto = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTaxaImposto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSubTotal6 = new System.Windows.Forms.TextBox();
            this.txtQuantidade6 = new System.Windows.Forms.TextBox();
            this.txtPrecoUnitario6 = new System.Windows.Forms.TextBox();
            this.txtDescricao6 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtItemNumero6 = new System.Windows.Forms.TextBox();
            this.txtSubTotal5 = new System.Windows.Forms.TextBox();
            this.txtQuantidade5 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPrecoUnitario5 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEstoqueItem)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtItemNumero5
            // 
            this.txtItemNumero5.Location = new System.Drawing.Point(16, 150);
            this.txtItemNumero5.Name = "txtItemNumero5";
            this.txtItemNumero5.Size = new System.Drawing.Size(45, 20);
            this.txtItemNumero5.TabIndex = 31;
            // 
            // txtSubTotal4
            // 
            this.txtSubTotal4.Location = new System.Drawing.Point(423, 123);
            this.txtSubTotal4.Name = "txtSubTotal4";
            this.txtSubTotal4.Size = new System.Drawing.Size(50, 20);
            this.txtSubTotal4.TabIndex = 29;
            this.txtSubTotal4.Text = "0,00";
            this.txtSubTotal4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQuantidade4
            // 
            this.txtQuantidade4.Location = new System.Drawing.Point(394, 123);
            this.txtQuantidade4.Name = "txtQuantidade4";
            this.txtQuantidade4.Size = new System.Drawing.Size(23, 20);
            this.txtQuantidade4.TabIndex = 28;
            this.txtQuantidade4.Text = "0";
            this.txtQuantidade4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQuantidade4.Leave += new System.EventHandler(this.txtPrecoUnitario4_Leave);
            // 
            // txtPrecoUnitario4
            // 
            this.txtPrecoUnitario4.Location = new System.Drawing.Point(338, 123);
            this.txtPrecoUnitario4.Name = "txtPrecoUnitario4";
            this.txtPrecoUnitario4.Size = new System.Drawing.Size(50, 20);
            this.txtPrecoUnitario4.TabIndex = 27;
            this.txtPrecoUnitario4.Text = "0,00";
            this.txtPrecoUnitario4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrecoUnitario4.Leave += new System.EventHandler(this.txtPrecoUnitario4_Leave);
            // 
            // txtDescricao4
            // 
            this.txtDescricao4.Location = new System.Drawing.Point(67, 123);
            this.txtDescricao4.Name = "txtDescricao4";
            this.txtDescricao4.Size = new System.Drawing.Size(265, 20);
            this.txtDescricao4.TabIndex = 26;
            // 
            // txtItemNumero4
            // 
            this.txtItemNumero4.Location = new System.Drawing.Point(16, 123);
            this.txtItemNumero4.Name = "txtItemNumero4";
            this.txtItemNumero4.Size = new System.Drawing.Size(45, 20);
            this.txtItemNumero4.TabIndex = 25;
            // 
            // txtSubTotal3
            // 
            this.txtSubTotal3.Location = new System.Drawing.Point(423, 97);
            this.txtSubTotal3.Name = "txtSubTotal3";
            this.txtSubTotal3.Size = new System.Drawing.Size(50, 20);
            this.txtSubTotal3.TabIndex = 23;
            this.txtSubTotal3.Text = "0,00";
            this.txtSubTotal3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQuantidade3
            // 
            this.txtQuantidade3.Location = new System.Drawing.Point(394, 97);
            this.txtQuantidade3.Name = "txtQuantidade3";
            this.txtQuantidade3.Size = new System.Drawing.Size(23, 20);
            this.txtQuantidade3.TabIndex = 22;
            this.txtQuantidade3.Text = "0";
            this.txtQuantidade3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQuantidade3.Leave += new System.EventHandler(this.txtPrecoUnitario3_Leave);
            // 
            // txtPrecoUnitario3
            // 
            this.txtPrecoUnitario3.Location = new System.Drawing.Point(338, 97);
            this.txtPrecoUnitario3.Name = "txtPrecoUnitario3";
            this.txtPrecoUnitario3.Size = new System.Drawing.Size(50, 20);
            this.txtPrecoUnitario3.TabIndex = 21;
            this.txtPrecoUnitario3.Text = "0,00";
            this.txtPrecoUnitario3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrecoUnitario3.Leave += new System.EventHandler(this.txtPrecoUnitario3_Leave);
            // 
            // txtDescricao3
            // 
            this.txtDescricao3.Location = new System.Drawing.Point(67, 97);
            this.txtDescricao3.Name = "txtDescricao3";
            this.txtDescricao3.Size = new System.Drawing.Size(265, 20);
            this.txtDescricao3.TabIndex = 20;
            // 
            // txtItemNumero3
            // 
            this.txtItemNumero3.Location = new System.Drawing.Point(16, 97);
            this.txtItemNumero3.Name = "txtItemNumero3";
            this.txtItemNumero3.Size = new System.Drawing.Size(45, 20);
            this.txtItemNumero3.TabIndex = 19;
            // 
            // txtSubTotal2
            // 
            this.txtSubTotal2.Location = new System.Drawing.Point(423, 71);
            this.txtSubTotal2.Name = "txtSubTotal2";
            this.txtSubTotal2.Size = new System.Drawing.Size(50, 20);
            this.txtSubTotal2.TabIndex = 17;
            this.txtSubTotal2.Text = "0,00";
            this.txtSubTotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQuantidade2
            // 
            this.txtQuantidade2.Location = new System.Drawing.Point(394, 71);
            this.txtQuantidade2.Name = "txtQuantidade2";
            this.txtQuantidade2.Size = new System.Drawing.Size(23, 20);
            this.txtQuantidade2.TabIndex = 16;
            this.txtQuantidade2.Text = "0";
            this.txtQuantidade2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQuantidade2.Leave += new System.EventHandler(this.txtPrecoUnitario2_Leave);
            // 
            // txtPrecoUnitario2
            // 
            this.txtPrecoUnitario2.Location = new System.Drawing.Point(338, 71);
            this.txtPrecoUnitario2.Name = "txtPrecoUnitario2";
            this.txtPrecoUnitario2.Size = new System.Drawing.Size(50, 20);
            this.txtPrecoUnitario2.TabIndex = 15;
            this.txtPrecoUnitario2.Text = "0,00";
            this.txtPrecoUnitario2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrecoUnitario2.Leave += new System.EventHandler(this.txtPrecoUnitario2_Leave);
            // 
            // txtDescricao2
            // 
            this.txtDescricao2.Location = new System.Drawing.Point(67, 71);
            this.txtDescricao2.Name = "txtDescricao2";
            this.txtDescricao2.Size = new System.Drawing.Size(265, 20);
            this.txtDescricao2.TabIndex = 14;
            // 
            // txtItemNumero2
            // 
            this.txtItemNumero2.Location = new System.Drawing.Point(16, 71);
            this.txtItemNumero2.Name = "txtItemNumero2";
            this.txtItemNumero2.Size = new System.Drawing.Size(45, 20);
            this.txtItemNumero2.TabIndex = 13;
            // 
            // colItemName
            // 
            this.colItemName.Text = "Nome/Descri��o Item";
            this.colItemName.Width = 354;
            // 
            // colItemNumber
            // 
            this.colItemNumber.Text = "Item #";
            this.colItemNumber.Width = 50;
            // 
            // colUnitPrice
            // 
            this.colUnitPrice.Text = "Pre�o";
            this.colUnitPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnNovoPedidoCliente
            // 
            this.btnNovoPedidoCliente.Location = new System.Drawing.Point(14, 182);
            this.btnNovoPedidoCliente.Name = "btnNovoPedidoCliente";
            this.btnNovoPedidoCliente.Size = new System.Drawing.Size(82, 23);
            this.btnNovoPedidoCliente.TabIndex = 16;
            this.btnNovoPedidoCliente.Text = "Novo Pedido";
            this.btnNovoPedidoCliente.UseVisualStyleBackColor = true;
            this.btnNovoPedidoCliente.Click += new System.EventHandler(this.btnNewCustomerOrder_Click);
            // 
            // btnNovoEstoqueItem
            // 
            this.btnNovoEstoqueItem.Location = new System.Drawing.Point(320, 46);
            this.btnNovoEstoqueItem.Name = "btnNovoEstoqueItem";
            this.btnNovoEstoqueItem.Size = new System.Drawing.Size(162, 23);
            this.btnNovoEstoqueItem.TabIndex = 75;
            this.btnNovoEstoqueItem.Text = "Novo Item...";
            this.btnNovoEstoqueItem.UseVisualStyleBackColor = true;
            this.btnNovoEstoqueItem.Click += new System.EventHandler(this.btnNewEstoqueItem_Click);
            // 
            // txtSubTotal1
            // 
            this.txtSubTotal1.Location = new System.Drawing.Point(423, 45);
            this.txtSubTotal1.Name = "txtSubTotal1";
            this.txtSubTotal1.Size = new System.Drawing.Size(50, 20);
            this.txtSubTotal1.TabIndex = 11;
            this.txtSubTotal1.Text = "0,00";
            this.txtSubTotal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQuantidade1
            // 
            this.txtQuantidade1.Location = new System.Drawing.Point(394, 45);
            this.txtQuantidade1.Name = "txtQuantidade1";
            this.txtQuantidade1.Size = new System.Drawing.Size(23, 20);
            this.txtQuantidade1.TabIndex = 10;
            this.txtQuantidade1.Text = "0";
            this.txtQuantidade1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQuantidade1.Leave += new System.EventHandler(this.txtPrecoUnitario1_Leave);
            // 
            // txtPrecoUnitario1
            // 
            this.txtPrecoUnitario1.Location = new System.Drawing.Point(338, 45);
            this.txtPrecoUnitario1.Name = "txtPrecoUnitario1";
            this.txtPrecoUnitario1.Size = new System.Drawing.Size(50, 20);
            this.txtPrecoUnitario1.TabIndex = 9;
            this.txtPrecoUnitario1.Text = "0,00";
            this.txtPrecoUnitario1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrecoUnitario1.Leave += new System.EventHandler(this.txtPrecoUnitario1_Leave);
            // 
            // txtDescricao1
            // 
            this.txtDescricao1.Location = new System.Drawing.Point(67, 45);
            this.txtDescricao1.Name = "txtDescricao1";
            this.txtDescricao1.Size = new System.Drawing.Size(265, 20);
            this.txtDescricao1.TabIndex = 8;
            // 
            // txtItemNumero1
            // 
            this.txtItemNumero1.Location = new System.Drawing.Point(16, 45);
            this.txtItemNumero1.Name = "txtItemNumero1";
            this.txtItemNumero1.Size = new System.Drawing.Size(45, 20);
            this.txtItemNumero1.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(427, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Sub Total";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(394, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Qtde";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(335, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Pre�o";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(64, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Descri��o";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Item #";
            // 
            // txtDescricao5
            // 
            this.txtDescricao5.Location = new System.Drawing.Point(67, 150);
            this.txtDescricao5.Name = "txtDescricao5";
            this.txtDescricao5.Size = new System.Drawing.Size(265, 20);
            this.txtDescricao5.TabIndex = 32;
            // 
            // btnRemove4
            // 
            this.btnRemove4.Enabled = false;
            this.btnRemove4.Location = new System.Drawing.Point(479, 121);
            this.btnRemove4.Name = "btnRemove4";
            this.btnRemove4.Size = new System.Drawing.Size(65, 23);
            this.btnRemove4.TabIndex = 46;
            this.btnRemove4.Text = "Remover";
            this.btnRemove4.UseVisualStyleBackColor = true;
            // 
            // btnRemove3
            // 
            this.btnRemove3.Enabled = false;
            this.btnRemove3.Location = new System.Drawing.Point(479, 95);
            this.btnRemove3.Name = "btnRemove3";
            this.btnRemove3.Size = new System.Drawing.Size(65, 23);
            this.btnRemove3.TabIndex = 45;
            this.btnRemove3.Text = "Remover";
            this.btnRemove3.UseVisualStyleBackColor = true;
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(102, 182);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(65, 23);
            this.btnFechar.TabIndex = 15;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRemove2
            // 
            this.btnRemove2.Enabled = false;
            this.btnRemove2.Location = new System.Drawing.Point(479, 68);
            this.btnRemove2.Name = "btnRemove2";
            this.btnRemove2.Size = new System.Drawing.Size(65, 23);
            this.btnRemove2.TabIndex = 44;
            this.btnRemove2.Text = "Remover";
            this.btnRemove2.UseVisualStyleBackColor = true;
            // 
            // btnAbrir
            // 
            this.btnAbrir.Location = new System.Drawing.Point(120, 155);
            this.btnAbrir.Name = "btnAbrir";
            this.btnAbrir.Size = new System.Drawing.Size(47, 23);
            this.btnAbrir.TabIndex = 14;
            this.btnAbrir.Text = "Abrir";
            this.btnAbrir.UseVisualStyleBackColor = true;
            this.btnAbrir.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnRemove6
            // 
            this.btnRemove6.Enabled = false;
            this.btnRemove6.Location = new System.Drawing.Point(479, 173);
            this.btnRemove6.Name = "btnRemove6";
            this.btnRemove6.Size = new System.Drawing.Size(65, 23);
            this.btnRemove6.TabIndex = 48;
            this.btnRemove6.Text = "Remover";
            this.btnRemove6.UseVisualStyleBackColor = true;
            // 
            // txtNumeroRecibo
            // 
            this.txtNumeroRecibo.Location = new System.Drawing.Point(66, 156);
            this.txtNumeroRecibo.Name = "txtNumeroRecibo";
            this.txtNumeroRecibo.Size = new System.Drawing.Size(48, 20);
            this.txtNumeroRecibo.TabIndex = 13;
            this.txtNumeroRecibo.Text = "000000";
            // 
            // btnRemove5
            // 
            this.btnRemove5.Enabled = false;
            this.btnRemove5.Location = new System.Drawing.Point(479, 147);
            this.btnRemove5.Name = "btnRemove5";
            this.btnRemove5.Size = new System.Drawing.Size(65, 23);
            this.btnRemove5.TabIndex = 47;
            this.btnRemove5.Text = "Remover";
            this.btnRemove5.UseVisualStyleBackColor = true;
            // 
            // btnRemove1
            // 
            this.btnRemove1.Enabled = false;
            this.btnRemove1.Location = new System.Drawing.Point(479, 42);
            this.btnRemove1.Name = "btnRemove1";
            this.btnRemove1.Size = new System.Drawing.Size(65, 23);
            this.btnRemove1.TabIndex = 42;
            this.btnRemove1.Text = "Remover";
            this.btnRemove1.UseVisualStyleBackColor = true;
            // 
            // pbxEstoqueItem
            // 
            this.pbxEstoqueItem.Location = new System.Drawing.Point(493, 17);
            this.pbxEstoqueItem.Name = "pbxEstoqueItem";
            this.pbxEstoqueItem.Size = new System.Drawing.Size(263, 232);
            this.pbxEstoqueItem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxEstoqueItem.TabIndex = 67;
            this.pbxEstoqueItem.TabStop = false;
            // 
            // cbxTipos
            // 
            this.cbxTipos.FormattingEnabled = true;
            this.cbxTipos.Location = new System.Drawing.Point(320, 17);
            this.cbxTipos.Name = "cbxTipos";
            this.cbxTipos.Size = new System.Drawing.Size(162, 21);
            this.cbxTipos.TabIndex = 73;
            this.cbxTipos.SelectedIndexChanged += new System.EventHandler(this.cbxTypes_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(257, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 72;
            this.label13.Text = "Item Tipo:";
            // 
            // cbxCategorias
            // 
            this.cbxCategorias.FormattingEnabled = true;
            this.cbxCategorias.Location = new System.Drawing.Point(93, 17);
            this.cbxCategorias.Name = "cbxCategorias";
            this.cbxCategorias.Size = new System.Drawing.Size(154, 21);
            this.cbxCategorias.TabIndex = 71;
            this.cbxCategorias.SelectedIndexChanged += new System.EventHandler(this.cbxCategories_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 70;
            this.label12.Text = "Categoria :";
            // 
            // lvwEstoqueItems
            // 
            this.lvwEstoqueItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colItemNumber,
            this.colItemName,
            this.colUnitPrice});
            this.lvwEstoqueItems.FullRowSelect = true;
            this.lvwEstoqueItems.GridLines = true;
            this.lvwEstoqueItems.Location = new System.Drawing.Point(12, 75);
            this.lvwEstoqueItems.Name = "lvwEstoqueItems";
            this.lvwEstoqueItems.Size = new System.Drawing.Size(470, 174);
            this.lvwEstoqueItems.TabIndex = 69;
            this.lvwEstoqueItems.UseCompatibleStateImageBehavior = false;
            this.lvwEstoqueItems.View = System.Windows.Forms.View.Details;
            this.lvwEstoqueItems.SelectedIndexChanged += new System.EventHandler(this.lvwStoreItems_SelectedIndexChanged);
            this.lvwEstoqueItems.DoubleClick += new System.EventHandler(this.lvwStoreItems_DoubleClick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 13);
            this.label14.TabIndex = 74;
            this.label14.Text = "Itens Dispon�veis";
            // 
            // txtTotalOrder
            // 
            this.txtTotalOrder.Location = new System.Drawing.Point(432, 614);
            this.txtTotalOrder.Name = "txtTotalOrder";
            this.txtTotalOrder.Size = new System.Drawing.Size(50, 20);
            this.txtTotalOrder.TabIndex = 65;
            this.txtTotalOrder.Text = "0.00";
            this.txtTotalOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnNovoPedidoCliente);
            this.groupBox1.Controls.Add(this.btnFechar);
            this.groupBox1.Controls.Add(this.btnAbrir);
            this.groupBox1.Controls.Add(this.txtNumeroRecibo);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.btnSalvar);
            this.groupBox1.Controls.Add(this.txtItemsTotal);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtTotalPedido);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtValorImposto);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtTaxaImposto);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(575, 255);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(181, 218);
            this.groupBox1.TabIndex = 68;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Resumo do Pedido";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 159);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Recibo #:";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(14, 119);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(153, 29);
            this.btnSalvar.TabIndex = 11;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtItemsTotal
            // 
            this.txtItemsTotal.Location = new System.Drawing.Point(85, 21);
            this.txtItemsTotal.Name = "txtItemsTotal";
            this.txtItemsTotal.Size = new System.Drawing.Size(56, 20);
            this.txtItemsTotal.TabIndex = 10;
            this.txtItemsTotal.Text = "0,00";
            this.txtItemsTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Items Total:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "%";
            // 
            // txtTotalPedido
            // 
            this.txtTotalPedido.Location = new System.Drawing.Point(85, 93);
            this.txtTotalPedido.Name = "txtTotalPedido";
            this.txtTotalPedido.Size = new System.Drawing.Size(56, 20);
            this.txtTotalPedido.TabIndex = 7;
            this.txtTotalPedido.Text = "0,00";
            this.txtTotalPedido.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Total Pedido:";
            // 
            // txtValorImposto
            // 
            this.txtValorImposto.Location = new System.Drawing.Point(85, 69);
            this.txtValorImposto.Name = "txtValorImposto";
            this.txtValorImposto.Size = new System.Drawing.Size(56, 20);
            this.txtValorImposto.TabIndex = 5;
            this.txtValorImposto.Text = "0,00";
            this.txtValorImposto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Valor Imposto";
            // 
            // txtTaxaImposto
            // 
            this.txtTaxaImposto.Location = new System.Drawing.Point(85, 45);
            this.txtTaxaImposto.Name = "txtTaxaImposto";
            this.txtTaxaImposto.Size = new System.Drawing.Size(37, 20);
            this.txtTaxaImposto.TabIndex = 3;
            this.txtTaxaImposto.Text = "7,75";
            this.txtTaxaImposto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTaxaImposto.Leave += new System.EventHandler(this.txtTaxRate_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Taxa Imposto";
            // 
            // txtSubTotal6
            // 
            this.txtSubTotal6.Location = new System.Drawing.Point(423, 176);
            this.txtSubTotal6.Name = "txtSubTotal6";
            this.txtSubTotal6.Size = new System.Drawing.Size(50, 20);
            this.txtSubTotal6.TabIndex = 41;
            this.txtSubTotal6.Text = "0,00";
            this.txtSubTotal6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQuantidade6
            // 
            this.txtQuantidade6.Location = new System.Drawing.Point(394, 176);
            this.txtQuantidade6.Name = "txtQuantidade6";
            this.txtQuantidade6.Size = new System.Drawing.Size(23, 20);
            this.txtQuantidade6.TabIndex = 40;
            this.txtQuantidade6.Text = "0";
            this.txtQuantidade6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQuantidade6.Leave += new System.EventHandler(this.txtPrecoUnitario6_Leave);
            // 
            // txtPrecoUnitario6
            // 
            this.txtPrecoUnitario6.Location = new System.Drawing.Point(338, 176);
            this.txtPrecoUnitario6.Name = "txtPrecoUnitario6";
            this.txtPrecoUnitario6.Size = new System.Drawing.Size(50, 20);
            this.txtPrecoUnitario6.TabIndex = 39;
            this.txtPrecoUnitario6.Text = "0,00";
            this.txtPrecoUnitario6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrecoUnitario6.Leave += new System.EventHandler(this.txtPrecoUnitario6_Leave);
            // 
            // txtDescricao6
            // 
            this.txtDescricao6.Location = new System.Drawing.Point(67, 176);
            this.txtDescricao6.Name = "txtDescricao6";
            this.txtDescricao6.Size = new System.Drawing.Size(265, 20);
            this.txtDescricao6.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(363, 618);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 13);
            this.label10.TabIndex = 64;
            this.label10.Text = "Order Total:";
            // 
            // txtItemNumero6
            // 
            this.txtItemNumero6.Location = new System.Drawing.Point(16, 176);
            this.txtItemNumero6.Name = "txtItemNumero6";
            this.txtItemNumero6.Size = new System.Drawing.Size(45, 20);
            this.txtItemNumero6.TabIndex = 37;
            // 
            // txtSubTotal5
            // 
            this.txtSubTotal5.Location = new System.Drawing.Point(423, 150);
            this.txtSubTotal5.Name = "txtSubTotal5";
            this.txtSubTotal5.Size = new System.Drawing.Size(50, 20);
            this.txtSubTotal5.TabIndex = 35;
            this.txtSubTotal5.Text = "0,00";
            this.txtSubTotal5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQuantidade5
            // 
            this.txtQuantidade5.Location = new System.Drawing.Point(394, 150);
            this.txtQuantidade5.Name = "txtQuantidade5";
            this.txtQuantidade5.Size = new System.Drawing.Size(23, 20);
            this.txtQuantidade5.TabIndex = 34;
            this.txtQuantidade5.Text = "0";
            this.txtQuantidade5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQuantidade5.Leave += new System.EventHandler(this.txtPrecoUnitario5_Leave);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnRemove6);
            this.groupBox2.Controls.Add(this.btnRemove5);
            this.groupBox2.Controls.Add(this.btnRemove4);
            this.groupBox2.Controls.Add(this.btnRemove3);
            this.groupBox2.Controls.Add(this.btnRemove2);
            this.groupBox2.Controls.Add(this.btnRemove1);
            this.groupBox2.Controls.Add(this.txtSubTotal6);
            this.groupBox2.Controls.Add(this.txtQuantidade6);
            this.groupBox2.Controls.Add(this.txtPrecoUnitario6);
            this.groupBox2.Controls.Add(this.txtDescricao6);
            this.groupBox2.Controls.Add(this.txtItemNumero6);
            this.groupBox2.Controls.Add(this.txtSubTotal5);
            this.groupBox2.Controls.Add(this.txtQuantidade5);
            this.groupBox2.Controls.Add(this.txtPrecoUnitario5);
            this.groupBox2.Controls.Add(this.txtDescricao5);
            this.groupBox2.Controls.Add(this.txtItemNumero5);
            this.groupBox2.Controls.Add(this.txtSubTotal4);
            this.groupBox2.Controls.Add(this.txtQuantidade4);
            this.groupBox2.Controls.Add(this.txtPrecoUnitario4);
            this.groupBox2.Controls.Add(this.txtDescricao4);
            this.groupBox2.Controls.Add(this.txtItemNumero4);
            this.groupBox2.Controls.Add(this.txtSubTotal3);
            this.groupBox2.Controls.Add(this.txtQuantidade3);
            this.groupBox2.Controls.Add(this.txtPrecoUnitario3);
            this.groupBox2.Controls.Add(this.txtDescricao3);
            this.groupBox2.Controls.Add(this.txtItemNumero3);
            this.groupBox2.Controls.Add(this.txtSubTotal2);
            this.groupBox2.Controls.Add(this.txtQuantidade2);
            this.groupBox2.Controls.Add(this.txtPrecoUnitario2);
            this.groupBox2.Controls.Add(this.txtDescricao2);
            this.groupBox2.Controls.Add(this.txtItemNumero2);
            this.groupBox2.Controls.Add(this.txtSubTotal1);
            this.groupBox2.Controls.Add(this.txtQuantidade1);
            this.groupBox2.Controls.Add(this.txtPrecoUnitario1);
            this.groupBox2.Controls.Add(this.txtDescricao1);
            this.groupBox2.Controls.Add(this.txtItemNumero1);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Location = new System.Drawing.Point(12, 255);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(557, 218);
            this.groupBox2.TabIndex = 66;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Itens Selecionados";
            // 
            // txtPrecoUnitario5
            // 
            this.txtPrecoUnitario5.Location = new System.Drawing.Point(338, 150);
            this.txtPrecoUnitario5.Name = "txtPrecoUnitario5";
            this.txtPrecoUnitario5.Size = new System.Drawing.Size(50, 20);
            this.txtPrecoUnitario5.TabIndex = 33;
            this.txtPrecoUnitario5.Text = "0,00";
            this.txtPrecoUnitario5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrecoUnitario5.Leave += new System.EventHandler(this.txtPrecoUnitario5_Leave);
            // 
            // LojaMusical
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(768, 485);
            this.Controls.Add(this.btnNovoEstoqueItem);
            this.Controls.Add(this.pbxEstoqueItem);
            this.Controls.Add(this.cbxTipos);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cbxCategorias);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lvwEstoqueItems);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtTotalOrder);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox2);
            this.Name = "LojaMusical";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Instrumentos Musicais - Ordem";
            this.Load += new System.EventHandler(this.LojaMusical_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxEstoqueItem)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtItemNumero5;
        private System.Windows.Forms.TextBox txtSubTotal4;
        private System.Windows.Forms.TextBox txtQuantidade4;
        private System.Windows.Forms.TextBox txtPrecoUnitario4;
        private System.Windows.Forms.TextBox txtDescricao4;
        private System.Windows.Forms.TextBox txtItemNumero4;
        private System.Windows.Forms.TextBox txtSubTotal3;
        private System.Windows.Forms.TextBox txtQuantidade3;
        private System.Windows.Forms.TextBox txtPrecoUnitario3;
        private System.Windows.Forms.TextBox txtDescricao3;
        private System.Windows.Forms.TextBox txtItemNumero3;
        private System.Windows.Forms.TextBox txtSubTotal2;
        private System.Windows.Forms.TextBox txtQuantidade2;
        private System.Windows.Forms.TextBox txtPrecoUnitario2;
        private System.Windows.Forms.TextBox txtDescricao2;
        private System.Windows.Forms.TextBox txtItemNumero2;
        private System.Windows.Forms.ColumnHeader colItemName;
        private System.Windows.Forms.ColumnHeader colItemNumber;
        private System.Windows.Forms.ColumnHeader colUnitPrice;
        private System.Windows.Forms.Button btnNovoPedidoCliente;
        private System.Windows.Forms.Button btnNovoEstoqueItem;
        private System.Windows.Forms.TextBox txtSubTotal1;
        private System.Windows.Forms.TextBox txtQuantidade1;
        private System.Windows.Forms.TextBox txtPrecoUnitario1;
        private System.Windows.Forms.TextBox txtDescricao1;
        private System.Windows.Forms.TextBox txtItemNumero1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtDescricao5;
        private System.Windows.Forms.Button btnRemove4;
        private System.Windows.Forms.Button btnRemove3;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnRemove2;
        private System.Windows.Forms.Button btnAbrir;
        private System.Windows.Forms.Button btnRemove6;
        private System.Windows.Forms.TextBox txtNumeroRecibo;
        private System.Windows.Forms.Button btnRemove5;
        private System.Windows.Forms.Button btnRemove1;
        private System.Windows.Forms.PictureBox pbxEstoqueItem;
        private System.Windows.Forms.ComboBox cbxTipos;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbxCategorias;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListView lvwEstoqueItems;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTotalOrder;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.TextBox txtItemsTotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTotalPedido;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtValorImposto;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTaxaImposto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSubTotal6;
        private System.Windows.Forms.TextBox txtQuantidade6;
        private System.Windows.Forms.TextBox txtPrecoUnitario6;
        private System.Windows.Forms.TextBox txtDescricao6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtItemNumero6;
        private System.Windows.Forms.TextBox txtSubTotal5;
        private System.Windows.Forms.TextBox txtQuantidade5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPrecoUnitario5;
    }
}

