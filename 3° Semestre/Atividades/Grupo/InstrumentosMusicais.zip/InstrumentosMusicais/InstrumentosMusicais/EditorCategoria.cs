using System.Windows.Forms;

namespace MusicalInstrumentStore2
{
    public partial class CategoryEditor : Form
    {
        public CategoryEditor()
        {
            InitializeComponent();
        }
    }
}